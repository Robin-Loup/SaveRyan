#ifndef __IN_OUT__
#define __IN_OUT__

#include "sudoku.h"

int fread_board(const char* file, Board board);

#endif

#include "bitarray.h"
#include<stdio.h>
#include <stdlib.h>

bitarray *create_bitarray(int m){
    bitarray *bits = (bitarray*)malloc(sizeof(bitarray));
    bits->table = (unsigned int*)malloc(sizeof(unsigned int)*m);
    bits->m = m;
    clear_bitarray(bits);
    return bits;
}

void free_bitarray(bitarray *a){
    free(a->table);
    free(a);
}

void set_bitarray (bitarray *a, int pos){
    a->table[pos] = 1;
}

void reset_bitarray(bitarray *a, int pos){
    a->table[pos] = 0;
}

int get_bitarray(bitarray *a, int pos){
    return a->table[pos];
}

void clear_bitarray(bitarray *a){
    int i;
    for ( i = 0; i < a->m; i++)
    {
        a->table[i] = 0;
    }   
}
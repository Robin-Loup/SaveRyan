#include "filter.h"
#include <stdio.h>
#include <stdlib.h>

#define M_DEFAULT 30
#define K_DEFAULT 10
#define MAX_WORD_LENGTH 80


int main(int argc, char **argv){
    filter *f;

    switch(argc){
        case 5 :
            f = create_filter(atoi(argv[3]), atoi(argv[4]));
            break;
        case 4 :
            f = create_filter(atoi(argv[3]),K_DEFAULT);
            break;
        case 3:
            f = create_filter(M_DEFAULT, K_DEFAULT);
            break;
        default :
            fprintf(stderr, "Error number argument\n");
        return 1;
    }
    FILE *fichier1 = fopen(argv[1], "r");
    if (fichier1 == NULL) {
        fprintf(stderr, "Error opening file for reading: %s\n", argv[1]);
        return 1;
    }

    char *word = (char *)malloc(MAX_WORD_LENGTH*sizeof(char));
    while (fscanf(fichier1, "%s ", word) != -1) {
        add_filter(f, word);
    }
    fclose(fichier1);

    FILE *fichier2 = fopen(argv[2], "r");
    if (fichier2 == NULL) {
        fprintf(stderr, "Error opening file for reading: %s\n", argv[2]);
        return 1;
    }
    
    FILE *fichier_find = fopen("words_find.txt", "w");
    if (fichier_find == NULL) {
        fprintf(stderr, "Error opening file for reading: words_find.txt\n");
        return 1;
    }

    FILE *fichier_not_find = fopen("words_not_find.txt", "w");
    if (fichier_find == NULL) {
        fprintf(stderr, "Error opening file for reading: words_not_find.txt\n");
        return 1;
    }


    while (fscanf(fichier2, "%s ", word) != -1) {
        if (is_member_filter(f, word))
            fprintf(fichier_find, "%s\n", word);
        else
            fprintf(fichier_not_find, "%s\n", word);
    }
    free(word);
    fclose(fichier2);
    fclose(fichier_find);
    fclose(fichier_not_find);
    free_filter(f);


    return 0;
}
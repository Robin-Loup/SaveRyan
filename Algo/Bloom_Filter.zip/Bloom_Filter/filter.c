#include "filter.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>

filter *create_filter(int m, int k){
    srand(time(NULL));
    int i;
    filter *fil = (filter *)malloc(sizeof(filter));
    fil->bits = create_bitarray(m);
    fil->poids = (unsigned *)malloc(sizeof(unsigned) *k);
    for(i = 0; i < k; i++){
        fil->poids[i] = rand() % m;
    }
    fil->m = m;
    fil->k = k;
    return fil;
}

void free_filter(filter *f){
     free_bitarray(f->bits);
     free(f->poids);
     free(f);
}

unsigned hachage(char *str, int k){
    int i;
    int h = 0;
    for(i = 0; str[i] != '\0'; i++){
        h = k * h + str[i];
    }
    return h;
}

void hash(filter *f, char *str, unsigned hashes[]){
    int i;
    for (i = 0; i < f->k; i++){
        hashes[i] = hachage(str, f->poids[i]);
    }
}

void add_filter(filter *f, char *str){
    int i;
    unsigned *hashes = (unsigned * )malloc(sizeof(unsigned) *f->k);
    for(i = 0; i < f->k; i++){
        hashes[i] = 0;
    }

    hash(f, str, hashes);
    
    for(i = 0; i < f->k; i++){
        set_bitarray(f->bits, hashes[i] % f->m);
    }
    free(hashes);
}

int is_member_filter(filter *f, char *str){
    int i;
    unsigned *hashes = (unsigned * )malloc(sizeof(unsigned) *f->k);
    for(i = 0; i < f->k; i++){
        hashes[i] = 0;
    }
    /*memset(hashes, 0, sizeof(unsigned) *f->m);;*/

    hash(f, str, hashes);
    
    for(i = 0; i < f->k; i++){
        if(get_bitarray(f->bits, hashes[i] % f->m) == 0){
            free(hashes);
            return 0;
        }
    }
    free(hashes);
    return 1;
}
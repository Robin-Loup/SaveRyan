#include "tp3.h"

int main(){
    /******Exercice 1******/
    /* Create the window */
	MLV_create_window("Draw", "Draw", 500, 500);
	MLV_draw_filled_rectangle(0, 0, 499, 499, BACKGROUND_COLOR);

    /* Draw the letter A */

    /* Wait and quit */

	MLV_wait_seconds(10);
	MLV_free_window();

	return 0;
}
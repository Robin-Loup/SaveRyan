#include "tp3.h"

/******Exercice 1******/
void H(int x, int y, int largeur){
    MLV_draw_line(200, 300, 250, 200, LINE_COLOR);
	/*MLV_draw_line(300, 300, 250, 200, LINE_COLOR);
	MLV_draw_line(225, 250, 275, 250, LINE_COLOR);
	MLV_update_window();
    if (largeur >= 8)
    {
        H(x,y,largeur/2);
    }*/
    
}
#include "tree.h"
#include <stdio.h>

int main() {

  node *t;
  t = NULL;

  return 0;
}

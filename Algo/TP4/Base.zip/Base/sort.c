#include <stdio.h>
#include <stdlib.h>
#include "sort.h"

int less(int a, int b) {
	return a < b;
}

void swap(int *a, int *b) {
	int tmp = *a;
	*a = *b;
	*b = tmp;
}

void selection_sort(int t[], int size) {
	/* TODO: à vous d'écrire la fonction */
}


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "array.h"
#include "sort.h"

#define MAX_VALUE 10000
#define MAX_SIZE 10

int main(int argc, char *argv[]) {

	srand(time(NULL));

	int size = MAX_SIZE;
	int max_value = MAX_VALUE;

	/* tableau de travail */
	int* tab = NULL;

	/* allocation et initialisation du tableau avec des valeurs aléatoires */
	tab = create_array(size);
	fill_random_array(tab, size, max_value);

	print_array(tab, size);

	/* tri du tableau */
	selection_sort(tab, size);
	
	print_array(tab, size);
	
	/* libération du tableau */
	free(tab);
	tab = NULL;

	return EXIT_SUCCESS;
}

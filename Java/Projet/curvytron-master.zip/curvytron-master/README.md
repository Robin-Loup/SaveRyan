# curvytron
=============
Curvytron JAVA

Jeu du snake type curvytron

## Projet

Ce projet de curvytron est codé en Java, et est une version jouable solo, implémentable
multijoueur. 
Une version multijoueur y est implémenté et à améliorer niveau fluidité.
(dû à la gestion des evenements de la librarie Zen5)

## API

L'interface d'affichage utilise la librairie Zen5.
La gestion d'événements passe aussi par la librarie Zen5.

Les serpents sont implémentés grâce à une interface AllSnake, qui permet 
de passer d'un serpent type curvytron à un serpent type snake classique.

La gestion de l'affichage se trouve dans la classe Window

Pour plus d'informations, se référer à la Javadoc fourni dans le dossier /CurvyTron/doc
(Javadoc re-générable au besoin).


## Librairies annexes

Le projet utilise la librairie Zen5, qui sera necessaire afin de faire fonctionner
l'interface graphique. Elle sera a rajouté dans la liste des librairies du projet.

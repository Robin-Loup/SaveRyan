package fr.upem.magazine;

public interface Eval {
	public int score();
}

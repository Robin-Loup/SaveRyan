package fr.upem;

public interface Eval {
	/**
	 * 
	 * we want to use interface cause we can't really define what is an Eval it is like asking someone 
	 * to define an Animal often they will just draw a cat but how we really define it ? 
	 * that why interface are better in this case.
	 */
	public float score();

}

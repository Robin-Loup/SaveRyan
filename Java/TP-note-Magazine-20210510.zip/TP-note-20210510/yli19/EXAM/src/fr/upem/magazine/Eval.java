package fr.upem.magazine;

/*
 * Interface
 */
public interface Eval {
	int score();
}

package fr.upem.magazine;

public interface Eval {
	
	public int score();
	
}

/*
 * question 5 
 * 
 * 	il est question de rendre une methode a plusieur classe disposant 
 * chacune de leur propre fonctionnement (champs differents) 
 * il est donc impossible de faire de l'heritage. 
 * autant utiliser une interface qui fait bien le travail.
 * 
 * 
 * */
 
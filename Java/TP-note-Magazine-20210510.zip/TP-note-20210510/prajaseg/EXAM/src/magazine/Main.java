package magazine;

public class Main {

}

package magazine;

public interface Eval {
	public int score();
	public String toString();
}

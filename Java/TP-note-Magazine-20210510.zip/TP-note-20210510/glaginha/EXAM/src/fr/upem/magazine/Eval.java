package fr.upem.magazine;

public interface Eval {
	int score();
	//  il ne faut pas faire de class abstraite car il n'y a aucun code en commun entre les classe LikeEval et StarEval
	// les deux classes fonction completement différament
}

package fr.upem.magazine;

public interface Eval {
	/* Return the score of the evalution based on their implementation */
	double score();

}

package fr.upem.magazine;

public interface Eval {
	
	public int score();
}

// Eval doit être une interface car nous souhaitons regrouper plusieurs 
	//classe différentes (surement avec des champs différents) possédant une même méthode
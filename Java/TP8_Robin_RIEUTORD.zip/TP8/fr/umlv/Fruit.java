package fr.umlv;

public interface Fruit {
	public int price();

}
